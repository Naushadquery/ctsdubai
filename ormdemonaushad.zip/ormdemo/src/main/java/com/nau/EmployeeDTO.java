package com.nau;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//@Getter
//@Setter
//@ToString
//@EqualsAndHashCode
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDTO {

	private int id;
	private String name;
	
	

//	public EmployeeDTO(int id, String name, String city,String email) {
//		super();
//		this.id = id;
//		this.name = name;
//		this.city = city;
//		this.email = email;
//	}
//	

}
