package com.nau;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import com.nau.dao.EmployeeDAOImpl;

public class OrmDemo1 {
	
	public static void main(String[] args) throws SQLException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {
		
		EmployeeDTO  dto1 = new EmployeeDTO();
	
		EmployeeDTO  dto2 = new EmployeeDTO(1,"akhtar");
		
		EmployeeDAOImpl daoImpl = new EmployeeDAOImpl();
		daoImpl.saveEmployee(dto2);
		
		
		
	}

}
