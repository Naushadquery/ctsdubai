package com.nau.dao;

import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.nau.EmployeeDTO;

public class NaushadORM {
	
	public void save(Object object) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException, SQLException {
		
//		String className = object.getClass().getName();
//		System.out.println(className);
//				
//		EmployeeDTO dto = (EmployeeDTO)Class.forName(className).getDeclaredConstructor().newInstance();
//		
//		String sql = "insert into employee values(?,?,?)";
//		int id=dto.getId();
//		String name= dto.getName();
//		String city = dto.getCity();
//		Connection connection=null;
//		PreparedStatement ps = connection.prepareStatement(sql);
//		ps.setInt(1, id);
//		ps.setString(2, name);
//		ps.setString(3, city);
//		
//		ps.executeUpdate();
		
		
	}

}
