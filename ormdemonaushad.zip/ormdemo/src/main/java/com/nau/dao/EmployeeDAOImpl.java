package com.nau.dao;

import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nau.EmployeeDTO;
import com.nau.util.DBConnection;

public class EmployeeDAOImpl {
	
	// ORM
	public void saveEmployee(EmployeeDTO dto ) throws SQLException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException, ClassNotFoundException {
		
	Session session = new DBConnection().getSession();
	Transaction tx = session.beginTransaction();
	
	session.save(dto);
	
	tx.commit();
	
	session.close();
	
	}
	

}
