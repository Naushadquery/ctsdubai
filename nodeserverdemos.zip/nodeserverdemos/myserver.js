var httpServer = require("http");
var fs = require("fs");
var url = require("url");
var uc = require('upper-case')

httpServer
  .createServer(function (req, res) {
    methodName = req.method;
    userUrl = req.url;
    var p;
    //  http://localhost/abc?name=naushad
    isquery = userUrl.indexOf("?"); // -1
    if (isquery == -1) {
      p = url;
    } else {
      p = userUrl.split("?")[0];
    }
    switch (p) {
      case "/": {
        fs.readFile("index.html", function (err, data) {
          res.write(data);
          res.end();
        });
        break;
      }
      case "/abc": {
        console.log("ABC");
        var q = url.parse(userUrl, true).query;
        console.log(q.uname);
        res.write(uc.upperCase(q.uname))
        res.end();
      }
    }
  })
  .listen(80);
