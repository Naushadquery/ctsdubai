var mysql = require("mysql");
//console.log(mysql)

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  user: "hr",
  password: "hr",
  database: "ctsdubai",
});

con.connect(function (err) {
  if (err) {
    console.log("No Connection");
  } else {
      console.log("Database Connected");
  }
});
module.exports = {con}