const { con} = require('./dbutil')
const {LoginUser} = require('./LoginUser')
function addLoginUser(loginuser) {
    userid = loginuser.userId;
    password = loginuser.password;
  sql = "insert into login values(?,?)";

  con.query(sql,[userid,password] ,function (err, result) {
    if(err){
        console.log(err);
    }else{
        console.log(result);
    }
  });
}

lu = new LoginUser(221,'akhtar');
addLoginUser(lu);

module.exports ={addLoginUser}

