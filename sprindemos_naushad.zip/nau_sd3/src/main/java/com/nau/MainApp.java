package com.nau;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nau.bean.view.EmployeeView;
import com.nau.config.MyBeanConfiguration;

public class MainApp {

	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext()) {
			ac.register(MyBeanConfiguration.class);
			ac.refresh();

			EmployeeView employeeView = ac.getBean(EmployeeView.class);
			employeeView.startVeiw();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
