package com.nau.bean.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.nau.dto.EmployeeDTO;

//@Repository
public class EmployeeDAOImpl implements EmployeeDAO{
	
	@Autowired
	Environment environment;

	@Override
	public void addEmployee(EmployeeDTO dto) {
		
		
		System.out.println("Empoyee " + dto + " added successfully" + environment.getProperty("city"));
	}

}
