package com.nau.bean.view;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.nau.bean.service.EmployeeService;
import com.nau.dto.EmployeeDTO;

@Component
public class EmployeeView {
	
//	@Autowired
//	private Environment environment;
	
	@Value("#{systemProperties['name']}")
	private String name;
	
	

	private Scanner scanner = new Scanner(System.in);
	
	@Autowired
	private EmployeeService employeeService ;

	public EmployeeView() {
		System.out.println("Employee View Created");
		
	}

	public void startVeiw() {
	//	System.out.println(environment.getProperty("name"));
		System.out.println("NAme : " + this.name );
		userOptions();

	}

	private void userOptions() {
		System.out.println("Enter Choice");
		int choice = scanner.nextInt();
		
		switch (choice) {
		case 1:{
			addEmployee();
			break;
		}
		case 2:{
			getEmployee();
		}
		default:
			break;
		}

	}

	private void getEmployee() {
		
		
	}

	private void addEmployee() {
		int id = 12345;
		String name = "Nasuhad";
		String city = "mumbai";

		EmployeeDTO dto = new EmployeeDTO(id,name);
		employeeService.addEmployee(dto);
		
	}

	public void exitView() {
		System.exit(0);
		return;
	}

}
