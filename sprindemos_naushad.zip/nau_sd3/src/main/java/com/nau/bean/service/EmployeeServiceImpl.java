package com.nau.bean.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.bean.dao.EmployeeDAO;
import com.nau.dto.EmployeeDTO;

@Service  // @Bean
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeDAO employeeDAO;
	
	@Override
	public void addEmployee(EmployeeDTO dto) {
		//
		employeeDAO.addEmployee(dto);
		//
		
	}
}
