package com.nau.bean.service;

import org.springframework.stereotype.Service;

import com.nau.dto.EmployeeDTO;



public interface EmployeeService {
	
	public void addEmployee(EmployeeDTO dto);

}
