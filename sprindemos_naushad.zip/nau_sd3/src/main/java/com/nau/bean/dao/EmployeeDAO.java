package com.nau.bean.dao;

import com.nau.dto.EmployeeDTO;

public interface EmployeeDAO {
	
	public void addEmployee(EmployeeDTO dto);

}
