package com.nau.bean.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.nau.dto.EmployeeDTO;

@Repository
public class EmployeeDAOImpl2 implements EmployeeDAO{
	
	@Autowired
	Environment environment;

	@Override
	public void addEmployee(EmployeeDTO dto) {
		System.out.println("Empoyee 2 " + dto + " added successfully"  + environment.getProperty("city"));
		
		
	}

}
