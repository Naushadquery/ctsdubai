package com.nau.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class TextEditor {
	
	@Autowired
	private SpellChecker spellChecker;// 
	
	public TextEditor() {
		System.out.println("default cons");
	}
	
	public String checkSpelling(String word) {
		return spellChecker.verifyWord(word);
		
	}
}
