package com.nau;

import org.springframework.beans.BeansException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.nau.bean.TextEditor;
import com.nau.config.MyBeanConfiguration;

public class MainApp {
	
	public static void main(String[] args) {
		try (AnnotationConfigApplicationContext ac = new AnnotationConfigApplicationContext()) {
			ac.register(MyBeanConfiguration.class);
			ac.refresh();
			TextEditor te =  ac.getBean(TextEditor.class); 
			String res = te.checkSpelling("hello");
			System.out.println(res);
		} catch (BeansException | IllegalStateException e) {
			e.printStackTrace();
		}
	} 

}
