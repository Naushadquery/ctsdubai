package com.nau.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.nau.bean"})
public class MyBeanConfiguration {

//	@Bean
//	public TextEditor textEditor() {
//		return new TextEditor();
//	}
//
//	@Bean
//	public SpellChecker englishSpellChecker() {
//		return new HindiSpellChecker();
//	}

//	@Bean
//	public SpellChecker hindiSpellChecker() {
//		return new HindiSpellChecker();
//	}
}
