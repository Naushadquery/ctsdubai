package com.nau.bean;

public interface SpellChecker {

	String verifyWord(String word);

}