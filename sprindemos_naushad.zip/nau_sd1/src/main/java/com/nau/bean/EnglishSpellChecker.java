package com.nau.bean;

public class EnglishSpellChecker implements SpellChecker {
	
	
	@Override
	public String verifyWord(String word) {
		if(word.equals("helo")) {
			return "ok";
		}else {
			return "bad";
		}
	}

}
