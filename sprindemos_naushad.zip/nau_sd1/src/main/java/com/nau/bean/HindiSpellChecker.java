package com.nau.bean;

public class HindiSpellChecker implements SpellChecker {
	
	
	@Override
	public String verifyWord(String word) {
		if(word.equals("helo")) {
			return "ok hindi";
		}else {
			return "bad hindi";
		}
	}

}
