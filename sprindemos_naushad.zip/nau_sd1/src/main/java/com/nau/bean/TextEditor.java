package com.nau.bean;

public class TextEditor {
	
	
	
	private SpellChecker spellChecker;// 
	
	public TextEditor() {
		// TODO Auto-generated constructor stub
	}

	public TextEditor(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}

	public String checkSpelling(String word) {
		return spellChecker.verifyWord(word);
		
	}

	public SpellChecker getSpellChecker() {
		return spellChecker;
	}

	public void setSpellChecker(SpellChecker spellChecker) {
		this.spellChecker = spellChecker;
	}
	
	

}
