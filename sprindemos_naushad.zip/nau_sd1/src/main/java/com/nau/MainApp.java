package com.nau;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.nau.bean.TextEditor;

public class MainApp {
	
	public static void main(String[] args) {
		
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");
		TextEditor te =  ac.getBean(TextEditor.class);
		String res = te.checkSpelling("hello");
		System.out.println(res);
	}

}
