package com.nau.bean.advice;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.nau.bean.view.EmployeeView;


@Aspect
@Component
public class EmployeeLogging {

	
	@Before("execution(* *.getMessage(..))")
	public void logBeforeMethod(JoinPoint joinpoint) throws Exception {
		System.out.println("Logging " + joinpoint.getSignature().getName() + " Before");
		
	}
	
	@After("execution(* *.getMessage(..))")
	public void logAfterMethod(JoinPoint joinpoint) throws Exception {
		System.out.println("Logging " + joinpoint.getSignature().getName() + " AFter");
		Object o = joinpoint.getTarget();
		EmployeeView s = (EmployeeView)o;
		if(s.getMessage().equals("jhj")) {
			throw new Exception("ASFD");
		}else {
			return;
		}
		
	}
	
}
