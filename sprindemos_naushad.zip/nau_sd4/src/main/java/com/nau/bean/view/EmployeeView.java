package com.nau.bean.view;

import org.springframework.stereotype.Component;

@Component
public class EmployeeView {
	
	
	
	public String getMessage() {
		//inside getmessage
		System.out.println("okokok");
		return "Hello";
		// exiting getmessage
	}
	

}
