function verifyUserByJQ(userid){
	$("#msgb").text("Waiting for Verification by JQuery....");
	var url = "verifyuser"; 
	$.post(url,{userid:userid},function(data){
		console.log(data);
		if(data=="0"){
			$("#msgb").text("User Not Available");
		}else{
			$("#msgb").text("User  Available");
		}
	});
}

function verifyUser(userid) {
	document.getElementById("msgb").innerHTML = "Waiting for Verification....";
	var url = "verifyuser"; // 
	var aakil = new XMLHttpRequest();
	aakil.open("POST", url, true);
	aakil.onreadystatechange = function() {
		if (aakil.readyState == 4) {
			data = aakil.responseText;
			if(data==="0"){
				message= "User Not Available"
			}else{
				data==="1"
				message= "User  Available"
			}
			document.getElementById("msgb").innerHTML = message;
		}
	}
	aakil.setRequestHeader("content-type","application/x-www-form-urlencoded");
	aakil.send("userid=" + userid);
}