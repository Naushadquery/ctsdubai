package com.nau.service;

import com.nau.vo.DepartmentResponse;

public interface DepartmentService {
	
	public DepartmentResponse getDepartmentById(Integer deptId);

}
