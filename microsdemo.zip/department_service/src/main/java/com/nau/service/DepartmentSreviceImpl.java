package com.nau.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.dao.DepartmentDAO;
import com.nau.entity.DepartmentEntity;
import com.nau.vo.DepartmentResponse;

@Service
public class DepartmentSreviceImpl implements DepartmentService {

	@Autowired
	private DepartmentDAO departmentDAO;

	@Autowired
	private ModelMapper mapper;
	@Override
	public DepartmentResponse getDepartmentById(Integer deptId) {

		Optional<DepartmentEntity> optional = departmentDAO.getDepartmentById(deptId);
		if(optional.isPresent()) {
			DepartmentEntity departmentEntity = optional.get();
			return mapper.map(departmentEntity, DepartmentResponse.class);
		}else {
			return null;
		}
	}

}
