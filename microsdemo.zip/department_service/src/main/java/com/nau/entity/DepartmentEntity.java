package com.nau.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="departmentservice")
public class DepartmentEntity {
	
	@Id
	@Column(name = "deptid")
	private Integer deptId;
	@Column(name = "deptname")
	private String deptName;
	@Column(name = "deptlocation")
	private String deptLocation;
	@Column(name = "deptdesc")
	private String deptDesc;

}
