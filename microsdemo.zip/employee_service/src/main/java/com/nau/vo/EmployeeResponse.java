package com.nau.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponse {
	
	private Integer empId;
	private String empName;
	private String empEmail;
	private Integer deptId;
}
