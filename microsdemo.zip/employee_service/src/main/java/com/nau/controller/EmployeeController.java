package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.service.EmployeeService;
import com.nau.vo.EmployeeDepartmentResponse;
import com.nau.vo.EmployeeResponse;

@RestController
@RequestMapping("employee")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping
	@RequestMapping("getemp/{empId}")
	public EmployeeResponse getEmployeeById(@PathVariable Integer empId) {
		return employeeService.getEmployeeById(empId);
	}

	@GetMapping("getempdept/{empId}")
	public EmployeeDepartmentResponse getEmpDept(@PathVariable Integer empId) {
		return employeeService.getEmpDept(empId);
	}

}
