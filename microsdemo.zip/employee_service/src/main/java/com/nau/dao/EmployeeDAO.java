package com.nau.dao;

import java.util.Optional;

import com.nau.entity.EmployeeEntity;

public interface EmployeeDAO {
	
	public Optional<EmployeeEntity> getEmployeeById(Integer deptId);

}
