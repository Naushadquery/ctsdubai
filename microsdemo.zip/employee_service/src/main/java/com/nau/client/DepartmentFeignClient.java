package com.nau.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nau.vo.DepartmentResponse;

@FeignClient(name="departmentFeignClient" , url = "http://localhost:6666")
public interface DepartmentFeignClient {
	
	@GetMapping("/dept/getdept/{deptId}")
	public DepartmentResponse getDepartmentById(@PathVariable Integer deptId);
	
}
