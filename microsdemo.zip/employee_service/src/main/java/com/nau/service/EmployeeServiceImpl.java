package com.nau.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nau.client.DepartmentFeignClient;
import com.nau.dao.EmployeeDAO;
import com.nau.entity.EmployeeEntity;
import com.nau.vo.DepartmentResponse;
import com.nau.vo.EmployeeDepartmentResponse;
import com.nau.vo.EmployeeResponse;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;

	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private DepartmentFeignClient departmentFeignClient;

	@Override
	public EmployeeDepartmentResponse getEmpDept(Integer empId) {

		EmployeeResponse employeeResponse = getEmployeeById(empId);
		Integer deptId = employeeResponse.getDeptId();
//		RestTemplate restTemplate = new RestTemplate();
//		String deptUrl = "http://localhost:6666/dept/getdept/" + deptId;
//		DepartmentResponse departmentResponse = restTemplate.getForObject(deptUrl, DepartmentResponse.class);
        DepartmentResponse departmentResponse =  departmentFeignClient.getDepartmentById(deptId);
		EmployeeDepartmentResponse response = new EmployeeDepartmentResponse(employeeResponse, departmentResponse);
		return response;
	}

	@Override
	public EmployeeResponse getEmployeeById(Integer empId) {
		Optional<EmployeeEntity> optional = employeeDAO.getEmployeeById(empId);
		if (optional.isPresent()) {
			EmployeeEntity employeeEntity = optional.get();
			System.out.println(employeeEntity);
			EmployeeResponse response = mapper.map(employeeEntity, EmployeeResponse.class);
			System.out.println(response);
			return response;
		} else {
			return null;
		}

	}

}
