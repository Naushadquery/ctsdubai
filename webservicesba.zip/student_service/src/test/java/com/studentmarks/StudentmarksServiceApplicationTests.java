package com.studentmarks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmarksServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
