package com.studentdetails;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.studentdetails.dao.StudentDetailsDAO;
import com.studentdetails.entity.StudentDetails;

@SpringBootApplication
public class StudentDetailsServiceApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(StudentDetailsServiceApplication.class, args);
		StudentDetailsDAO dao = ctx.getBean(StudentDetailsDAO.class);
		Optional<StudentDetails> optional = dao.getStudentDetails(111);
		System.out.println(optional.get());

	}

	@Bean
	public ModelMapper getModelMapper() {
		return new ModelMapper();
	}

}
