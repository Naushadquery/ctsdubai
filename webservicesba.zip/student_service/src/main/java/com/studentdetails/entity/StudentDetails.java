package com.studentdetails.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "studentdetails")
public class StudentDetails {
	
	@Id
	private Integer studentId;
	private String firstName;
	private String lastName;
	private String grade;

}
