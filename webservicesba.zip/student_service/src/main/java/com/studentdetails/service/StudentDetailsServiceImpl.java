package com.studentdetails.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentdetails.dao.StudentDetailsDAO;
import com.studentdetails.dto.StudentDetailResponse;
import com.studentdetails.entity.StudentDetails;

@Service
public class StudentDetailsServiceImpl implements StudentDetailsService {

	@Autowired
	private StudentDetailsDAO marksDAO;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public StudentDetailResponse getStudentDetailsById(Integer studentId) {

		Optional<StudentDetails> optional = marksDAO.getStudentDetails(studentId);
		if(optional.isPresent()) {
			StudentDetails details = optional.get();
			StudentDetailResponse studentDetails = mapper.map(details, StudentDetailResponse.class);
			return studentDetails;
		}else {
			return null;
		}
	}
}
