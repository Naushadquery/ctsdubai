package com.studentdetails.service;

import com.studentdetails.dto.StudentDetailResponse;

public interface StudentDetailsService {
	
	public StudentDetailResponse getStudentDetailsById(Integer studentId);
 
}
