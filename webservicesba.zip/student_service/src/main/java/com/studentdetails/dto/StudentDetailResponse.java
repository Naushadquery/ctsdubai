package com.studentdetails.dto;

import lombok.Data;

@Data
public class StudentDetailResponse {
	
	private Integer studentId;
	private String firstName;
	private String lastName;
	private String grade;
	

}
