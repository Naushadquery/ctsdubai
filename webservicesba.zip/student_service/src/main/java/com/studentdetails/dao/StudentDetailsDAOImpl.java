package com.studentdetails.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.studentdetails.entity.StudentDetails;
import com.studentdetails.repository.StudentDetailRepository;

@Repository
public class StudentDetailsDAOImpl implements StudentDetailsDAO {

	@Autowired
	private StudentDetailRepository  studentDetailRepository;

	@Override
	public Optional<StudentDetails> getStudentDetails(Integer studentId) {

		return studentDetailRepository.findById(studentId);

	}
}
