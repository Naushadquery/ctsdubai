package com.studentdetails.dao;

import java.util.Optional;

import com.studentdetails.entity.StudentDetails;

public interface StudentDetailsDAO {
	
	public Optional<StudentDetails> getStudentDetails(Integer studentId);

}
