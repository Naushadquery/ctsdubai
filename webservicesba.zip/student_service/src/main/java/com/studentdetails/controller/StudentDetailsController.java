package com.studentdetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentdetails.dto.StudentDetailResponse;
import com.studentdetails.service.StudentDetailsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/studentdetails")
@Slf4j // AOP
public class StudentDetailsController {

	@Autowired
	private StudentDetailsService detailsService;

	@GetMapping
	@RequestMapping("/getbyid/{studentId}")
	public StudentDetailResponse getStudentMarksById(@PathVariable("studentId") Integer studentId) {
		log.info("Inside getStudentMarksById method with id : {}", studentId);
		StudentDetailResponse marksResponse = detailsService.getStudentDetailsById(studentId);
		log.info("Result from service : " + marksResponse);
		return marksResponse;
	}
}
