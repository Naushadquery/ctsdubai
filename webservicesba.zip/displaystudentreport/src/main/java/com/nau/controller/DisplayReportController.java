package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.nau.service.DisplayStudentReportService;
import com.nau.vo.StudentDetailsVO;
import com.nau.vo.StudentMarksVO;
import com.nau.vo.Student_Detail_MarksVO;

@Controller
@RequestMapping("displayreport")
public class DisplayReportController {

	@Autowired
	private DisplayStudentReportService reportService;

	@GetMapping
	@RequestMapping("getbyid")
	public String getReportById(Integer studentId, Model model) {
		
	    Student_Detail_MarksVO vo =  reportService.getReport(studentId);
	    
	    StudentDetailsVO detailsVO = vo.getDetailsVO();
	    StudentMarksVO  marksVO =  vo.getMarksVO();
	    
	    Integer studentid = detailsVO.getStudentId();
	    String studentFname = detailsVO.getFirstName();
	    String studentLname = detailsVO.getLastName();
	    String studentGrade = detailsVO.getGrade();
	    
	    String fullname = studentFname +" " + studentLname;
		
	    Integer physics = marksVO.getPhysics();
	    Integer chemistry = marksVO.getChemistry();
	    Integer maths = marksVO.getMaths();
	    
	    Integer total = physics+chemistry+maths;
	    Integer average = total/3;
	    
	    model.addAttribute("fullname", fullname);
	    model.addAttribute("grade", studentGrade);
	    model.addAttribute("studentid", studentid);
	    model.addAttribute("physics", physics);
	    model.addAttribute("maths", maths);
	    model.addAttribute("chemistry", chemistry);
	    model.addAttribute("total", total);
	    model.addAttribute("average", average);
	    
		return "studentreport";
	}

}
