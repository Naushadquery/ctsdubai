package com.nau.vo;

import lombok.Data;

@Data
public class StudentMarksVO {
	private Integer studentId;
	private Integer physics;
	private Integer maths;
	private Integer chemistry;
}
