package com.nau.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data

public class StudentDetailsVO {
	private Integer studentId;
	private String firstName;
	private String lastName;
	private String grade;
}
