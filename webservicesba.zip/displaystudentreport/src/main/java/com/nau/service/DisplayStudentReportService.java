package com.nau.service;

import com.nau.vo.Student_Detail_MarksVO;

public interface DisplayStudentReportService {

	public Student_Detail_MarksVO getReport(Integer studentId);
	
}
