package com.nau.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nau.vo.StudentDetailsVO;
import com.nau.vo.StudentMarksVO;
import com.nau.vo.Student_Detail_MarksVO;

@Service
public class DisplayStudentReportServiceImpl implements DisplayStudentReportService {

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Student_Detail_MarksVO getReport(Integer studentId) {

		// student details;
		String urldetails = "http://localhost:9090/studentdetails/getbyid/" + studentId;
		StudentDetailsVO ud = restTemplate.getForObject(urldetails, StudentDetailsVO.class);
		System.out.println(ud);

		
		
		// student marks;
		String urlmarks = "http://localhost:8080/studentmarks/getbyid/" + studentId;
		StudentMarksVO um = restTemplate.getForObject(urlmarks, StudentMarksVO.class);
		System.out.println(um);
		Student_Detail_MarksVO vo = new Student_Detail_MarksVO(ud, um);
		
		System.out.println(vo);
		return vo;
	}
}
