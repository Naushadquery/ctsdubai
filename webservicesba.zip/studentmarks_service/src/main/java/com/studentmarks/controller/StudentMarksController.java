package com.studentmarks.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentmarks.dto.StudentMarksResponse;
import com.studentmarks.service.StudentMarksService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/studentmarks")
@Slf4j // AOP
public class StudentMarksController {

	@Autowired
	private StudentMarksService marksService;

	@GetMapping
	@RequestMapping("/getbyid/{studentId}")
	public StudentMarksResponse getStudentMarksById(@PathVariable("studentId") Integer studentId) {
		log.info("Inside getStudentMarksById method with id : {}", studentId);
		StudentMarksResponse marksResponse = marksService.getStudentMarksById(studentId);
		log.info("Result from service : " + marksResponse);
		return marksResponse;
	}
}
