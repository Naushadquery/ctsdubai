package com.studentmarks.dto;

import lombok.Data;

@Data
public class StudentMarksResponse {
	
	private Integer studentId;
	private Integer physics;
	private Integer maths;
	private Integer chemistry;
	

}
