package com.studentmarks.service;

import com.studentmarks.dto.StudentMarksResponse;

public interface StudentMarksService {
	
	
	public StudentMarksResponse getStudentMarksById(Integer studentId);
 
}
