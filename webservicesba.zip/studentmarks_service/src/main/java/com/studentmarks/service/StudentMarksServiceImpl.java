package com.studentmarks.service;

import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentmarks.dao.StudentMarksDAO;
import com.studentmarks.dto.StudentMarksResponse;
import com.studentmarks.entity.StudentMarks;

@Service
public class StudentMarksServiceImpl implements StudentMarksService {

	@Autowired
	private StudentMarksDAO marksDAO;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public StudentMarksResponse getStudentMarksById(Integer studentId) {

		Optional<StudentMarks> optional = marksDAO.getStudentMarks(studentId);
		if(optional.isPresent()) {
			StudentMarks marks = optional.get();
			StudentMarksResponse studentMarks = mapper.map(marks, StudentMarksResponse.class);
			return studentMarks;
		}else {
			return null;
		}
	}
}
