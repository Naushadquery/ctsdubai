package com.studentmarks;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class StudentmarksServiceApplication {

	public static void main(String[] args) {
	ApplicationContext ctx = SpringApplication.run(StudentmarksServiceApplication.class, args);
//	StudentMarksDAO  dao = ctx.getBean(StudentMarksDAO.class);
//	Optional<StudentMarks> optional= dao.getStudentMarks(111);
//	System.out.println(optional.get());
	
	}
	
	@Bean
	public ModelMapper getModelMapper() {
		return new ModelMapper();
	}

}
