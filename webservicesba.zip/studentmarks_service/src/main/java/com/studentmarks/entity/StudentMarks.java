package com.studentmarks.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "studentmarks")
public class StudentMarks {
	
	@Id
	private Integer studentId;
	private Integer physics;
	private Integer maths;
	private Integer chemistry;

}
