package com.studentmarks.dao;

import java.util.Optional;

import com.studentmarks.entity.StudentMarks;

public interface StudentMarksDAO {
	
	public Optional<StudentMarks> getStudentMarks(Integer studentId);

}
