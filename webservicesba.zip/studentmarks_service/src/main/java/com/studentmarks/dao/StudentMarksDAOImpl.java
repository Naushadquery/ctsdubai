package com.studentmarks.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.studentmarks.entity.StudentMarks;
import com.studentmarks.repository.StudentMarksRepository;

@Repository
public class StudentMarksDAOImpl implements StudentMarksDAO {

	@Autowired
	private StudentMarksRepository studentMarksRepository;

	@Override
	public Optional<StudentMarks> getStudentMarks(Integer studentId) {

		return studentMarksRepository.findById(studentId);

	}
}
