package com.nau.service;

import com.nau.dao.LoginDAO;
import com.nau.dto.UserDTO;

public class LoginService {

	public String validate(UserDTO userDTO) {

		LoginDAO dao = new LoginDAO();
		UserDTO userDTOFromDB = dao.getUser(userDTO.getUid());
		if (userDTOFromDB == null) {
			return "0";
		} else {
			if(userDTO.getPassword().equals(userDTOFromDB.getPassword())) {
				return "1";
			}else {
				return "2";
			}
		}
	}
}
