package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nau.dto.UserDTO;
import com.nau.util.DBConnection;

public class LoginDAO {
	
	private Connection connection = DBConnection.getConnection();
	
	
	public UserDTO getUser(String uid) {
//		String sql = "select * from user where uid=?";
//		try (PreparedStatement ps = connection.prepareStatement(sql)) {
//			ps.setString(1, uid);
//			ResultSet rs = ps.executeQuery();
//			if(rs.next()) {
//				return new UserDTO(uid, rs.getString("password"));
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		if(uid.equals("nau")) {
			return new UserDTO("nau", "nau");
			
		}else {
			return null;
		}
	
	}

}
