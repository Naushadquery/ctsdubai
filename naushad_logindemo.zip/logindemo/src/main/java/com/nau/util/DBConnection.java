package com.nau.util;

import java.sql.Connection;

public class DBConnection {
	
	
	private  static Connection connection;

	
	public static  Connection getConnection() {
		
		return connection;
	}
	
}
