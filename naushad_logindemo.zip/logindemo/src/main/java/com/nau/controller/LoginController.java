package com.nau.controller;

import java.io.IOException;

import com.nau.dto.UserDTO;
import com.nau.service.LoginService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Login Servelet");
		String uid = request.getParameter("uid");
		String password = request.getParameter("password");
		UserDTO dto = new UserDTO(uid,password);
		LoginService loginService = new LoginService();
		String s = loginService.validate(dto);
		switch (s) {
		case "0": {
			request.setAttribute("message", "Sorry, User Does Not Exists !");
			request.getRequestDispatcher("/WEB-INF/jsp/loginpage.jsp").forward(request, response);
			break;
		}
		case "1" : {
			request.getRequestDispatcher("/WEB-INF/jsp/welcome.jsp").forward(request, response);
			break;
		}case "2" : {
			request.setAttribute("message", "Sorry, Password is Wrong !");
			request.getRequestDispatcher("/WEB-INF/jsp/loginpage.jsp").forward(request, response);
			break;
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + s);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
