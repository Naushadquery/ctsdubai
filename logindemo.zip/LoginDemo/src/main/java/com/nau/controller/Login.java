package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nau.dto.UserDTO;
import com.nau.service.LoginService;

@Controller
@RequestMapping("login")
public class Login {
	
	@Autowired
	private LoginService loginService;
	
	@PostMapping
	@RequestMapping("saveuser")
	public String saveUser(UserDTO userDTO) {
		System.out.println(userDTO);
		
		loginService.addUser(userDTO);
		
		return "";
	}

}
