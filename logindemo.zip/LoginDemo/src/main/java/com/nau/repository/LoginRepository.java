package com.nau.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nau.entity.UserEntity;

public interface LoginRepository extends JpaRepository<UserEntity, Integer>{

}
