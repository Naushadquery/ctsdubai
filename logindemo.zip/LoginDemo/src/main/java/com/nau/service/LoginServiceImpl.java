package com.nau.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.dao.LoginDAO;
import com.nau.dto.UserDTO;
import com.nau.entity.UserEntity;


@Service 
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	private LoginDAO loginDAO;
	
	private ModelMapper mapper = new ModelMapper();

	@Override
	public void addUser(UserDTO userDTO) {
		
		UserEntity userEntity = mapper.map(userDTO, UserEntity.class);
		
		loginDAO.addUser(userEntity);
		
		
	}

}
