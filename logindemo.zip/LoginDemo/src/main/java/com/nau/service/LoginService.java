package com.nau.service;

import com.nau.dto.UserDTO;

public interface LoginService {
	
	public void addUser(UserDTO userDTO);

}
