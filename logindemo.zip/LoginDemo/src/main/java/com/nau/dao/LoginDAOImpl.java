package com.nau.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.entity.UserEntity;
import com.nau.repository.LoginRepository;


@Repository
public class LoginDAOImpl implements LoginDAO {
	
	
	@Autowired
	private LoginRepository loginRepository;

	@Override
	public void addUser(UserEntity entity) {
		
		loginRepository.findById(entity.getUserid());
		
		loginRepository.save(entity);
		
	}

}
