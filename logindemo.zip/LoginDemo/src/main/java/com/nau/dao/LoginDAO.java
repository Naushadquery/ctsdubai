package com.nau.dao;

import com.nau.entity.UserEntity;

public interface LoginDAO {
	
	public void addUser(UserEntity entity);

}
