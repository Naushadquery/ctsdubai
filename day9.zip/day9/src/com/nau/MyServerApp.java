package com.nau;

public class MyServerApp {

	
	public static void main(String[] args) {
		System.out.println("MyServerApp.main()");
		new NoufHouse();
	}
}