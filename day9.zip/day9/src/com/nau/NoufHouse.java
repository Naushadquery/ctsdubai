package com.nau;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class NoufHouse {

	public NoufHouse() {

		try (ServerSocket ss = new ServerSocket(1234)) {

			for (;;) {
				System.out.println("Waiting for Clients");
				Socket socket = ss.accept();
				System.out.println(socket);
				String message = "Welcome to Nouf Office";
				try (OutputStream os = socket.getOutputStream(); 
						PrintWriter out = new PrintWriter(os)) {
					out.print(message);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
