package com.nau;

import java.io.*;
import java.net.*;

public class Naushad {

	public static void main(String[] args) throws UnknownHostException, IOException {

		Socket s = new Socket("localhost",1234);
		InputStream is = s.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String message = br.readLine();
		System.out.println(message);
		
	}

}
