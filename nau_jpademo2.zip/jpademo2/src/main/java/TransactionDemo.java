import javax.transaction.Transactional;

public class TransactionDemo {
	
	@Transactional
	public void m1() {
		m3();
		m2();
		System.out.println("End");
	}
	
	// tx B
	public void m2() {
		String sql="insert into abc values(1,'aabc')";// fired // rollback
		//savepoint
		m3();
	}
	//tx c
	public void m3() {
		String sql="insert into ddd values(1,'dd')";// fired  // rollback
		// error
	}

}
