package com.nau.app;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.nau.entity.Library;
import com.nau.entity.Student;
import com.nau.util.JPAUtil;

public class OneToOneUsingEntity {

	public static void main(String[] args) {

		Student student = new Student();
		student.setS_name("ahmad");
		
		Library library = new Library();
		library.setB_name("net");
		library.setStudent(student);
		
		EntityManager entityManager = JPAUtil.getEntityManager();
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();

		//entityManager.persist(student);
		entityManager.persist(library);

		tx.commit();
		entityManager.close();
		
	}
}
