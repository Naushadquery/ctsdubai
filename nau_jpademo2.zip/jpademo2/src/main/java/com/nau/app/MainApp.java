package com.nau.app;

import com.nau.dao.PersonDAOImpl;
import com.nau.entity.Address;
import com.nau.entity.PersonEntity;

public class MainApp {

	public static void main(String[] args) {

	//Address temp = new Address("sharjah", "UAE");	
	Address perm = new Address("mumbai", "India");	
	PersonEntity entity = new PersonEntity(2, "naushad",perm);
		PersonDAOImpl daoImpl = new PersonDAOImpl();
	daoImpl.addPerson(entity);
//		PersonEntity personEntity = daoImpl.getPerson(1);
	//	System.out.println(personEntity);
	
		
//		System.out.println(personEntity.getPid() + " " + personEntity.getName() + " " + address.getCity() + " "
//				+ address.getCountry());

	}
}
