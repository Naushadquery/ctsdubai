package com.nau.app;

import java.util.ArrayList;
import java.util.List;

import com.nau.dao.EmployeeDAO;
import com.nau.entity.Address;
import com.nau.entity.Employee;

public class OneToManyUsingCollection {

	public static void main(String[] args) {
//
//		Address address1 = new Address("mumbai", "India");
//		Address address2 = new Address("dubai", "UAE");
//
//		Employee employee = new Employee();
//		employee.setE_name("naushad");
//		employee.getAddress().add(address2);
//		employee.getAddress().add(address1);

		EmployeeDAO dao = new EmployeeDAO();
		// dao.addEmployee(employee);
		List<Employee> employees = dao.getEmployees();
		Employee e = employees.get(0);
		System.out.println(e.getE_id() + " " + e.getE_name());
		List<Address> empaddress = e.getAddress();
		empaddress.forEach((a)->System.out.println(a));

	}
}
