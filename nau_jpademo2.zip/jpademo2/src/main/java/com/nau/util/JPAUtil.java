package com.nau.util;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {
	
	
	private static EntityManagerFactory factory;
	static {
		
	//	Map<String, String> props= new HashMap<>();
		factory = Persistence.createEntityManagerFactory("StudentPU");	
		System.out.println("factory created");	
	}
	public static EntityManager getEntityManager() {
		EntityManager manager = factory.createEntityManager();
		return manager;
	}
}
