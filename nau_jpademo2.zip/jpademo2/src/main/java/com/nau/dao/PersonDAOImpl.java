package com.nau.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.nau.entity.PersonEntity;
import com.nau.util.JPAUtil;

public class PersonDAOImpl {

	// private EntityManager entityManager = JPAUtil.getEntityManager();

	public void addPerson(PersonEntity entity) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();

		entityManager.persist(entity);

		tx.commit();
		entityManager.close();
	}

	public PersonEntity getPerson(int pid) {
		EntityManager entityManager = JPAUtil.getEntityManager();

		PersonEntity entity = entityManager.find(PersonEntity.class, pid);

		entityManager.close();

		return entity;
	}

}
