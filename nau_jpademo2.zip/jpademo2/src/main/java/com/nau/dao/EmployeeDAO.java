package com.nau.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.nau.entity.Employee;
import com.nau.util.JPAUtil;

public class EmployeeDAO {

	// private EntityManager entityManager = JPAUtil.getEntityManager();

	public void addEmployee(Employee employee) {
		EntityManager entityManager = JPAUtil.getEntityManager();
		EntityTransaction tx = entityManager.getTransaction();
		tx.begin();

		entityManager.persist(employee);

		tx.commit();
		entityManager.close();
	}
	
	public List<Employee> getEmployees(){
		EntityManager entityManager = JPAUtil.getEntityManager();
		TypedQuery<Employee> query = entityManager.createQuery("from Employee", Employee.class);
		return query.getResultList();
	}


}
