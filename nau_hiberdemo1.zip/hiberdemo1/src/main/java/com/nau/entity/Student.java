package com.nau.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {

	private int rollNo;
	private String studentName;
	private String studentCity;
	public Student(int rollNo) {
		super();
		this.rollNo = rollNo;
	}
	
	
	
}
