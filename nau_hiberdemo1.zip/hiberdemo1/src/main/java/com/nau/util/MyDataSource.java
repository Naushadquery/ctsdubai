package com.nau.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MyDataSource {
	
	static SessionFactory sessionFactory;

	static{
		Configuration configuration = new Configuration();
		configuration.configure();// search for file hibernate.cfg.xml
		sessionFactory = configuration.buildSessionFactory();
	}
	
	public static Session getSession() {
		return sessionFactory.openSession();
	}
	
}
