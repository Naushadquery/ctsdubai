package com.nau.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import com.nau.entity.Student;
import com.nau.util.MyDataSource;

public class StudentDAOImpl {

	public void addStudent(Student student) {
		Session session = MyDataSource.getSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(student);

		tx.commit();
		session.close();
	}

	public void updateStudent(Student student) {
		Session session = MyDataSource.getSession();
		Transaction tx = session.beginTransaction();
		session.update(student);
		tx.commit();
		session.close();
	}

	public void deleteStudent(int i) {
		Session session = MyDataSource.getSession();
		Transaction tx = session.beginTransaction();
		session.delete(new Student(i));
		tx.commit();
		session.close();
	}

	public Student getStudent(int id) {
		Session session = MyDataSource.getSession();
		Student student = session.find(Student.class, id);
		session.close();
		return student;
	}

	public List<Student> getAllStudent() {
		Session session = MyDataSource.getSession();
		
	//	String hql = "from Student"; // hibernate query language
	//	Query<Student>  query =  session.createQuery(hql);
	//	List<Student> slist =  query.getResultList();
	//	slist.forEach((s)->System.out.println(s));
		String sql ="select * from student_h1"; // on table
		NativeQuery<Student> nquery=  session.createNativeQuery(sql, Student.class);
		List<Student> slist  = nquery.getResultList();
		session.close();
		return slist;
	}

}
