package cmo.nau.app;

import java.util.List;

import com.nau.dao.StudentDAOImpl;
import com.nau.entity.Student;

public class MainApplication {

	public static void main(String[] args) {
		//addStudent();// save and update
		//update();// update
		// delete(); // delete
		//getStudent(); // find by id
		getAllStudents();
	}
	private static void getAllStudents() {
		StudentDAOImpl studentDAOImpl = new StudentDAOImpl();
		List<Student> lists = studentDAOImpl.getAllStudent();
		lists.forEach((s)->System.out.println(s));
		
	}
	private static void getStudent() {
		StudentDAOImpl studentDAOImpl = new StudentDAOImpl();
		Student student = studentDAOImpl.getStudent(1);
		System.out.println(student);
		
	}
	private static void delete() {
		StudentDAOImpl studentDAOImpl = new StudentDAOImpl();
		studentDAOImpl.deleteStudent(12);
	}
	private static void update() {
		Student student = new Student(12,"Nouf","dubai");
		StudentDAOImpl studentDAOImpl = new StudentDAOImpl();
		studentDAOImpl.updateStudent(student);
	}
	
	private static void addStudent() {
		Student student = new Student(12,"cathy","mumbai");
		StudentDAOImpl studentDAOImpl = new StudentDAOImpl();
		studentDAOImpl.addStudent(student);
	}
}
