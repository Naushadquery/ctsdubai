package com.nau.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDepartmentResponse {
	
	private EmployeeResponse employeeResponse;
	private DepartmentResponse departmentResponse;
	

}
