package com.nau.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.entity.EmployeeEntity;
import com.nau.repository.EmployeeRepository;


@Repository
public class EmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	
	@Override
	public Optional<EmployeeEntity> getEmployeeById(Integer empId) {
		
		return employeeRepository.findById(empId);
	}
	
}
