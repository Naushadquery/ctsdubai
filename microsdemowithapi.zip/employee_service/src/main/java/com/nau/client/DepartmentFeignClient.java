package com.nau.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.nau.vo.DepartmentResponse;

@FeignClient(name = "DEPARTMENT-SERVICE")
public interface DepartmentFeignClient {
	@GetMapping("/dept/getdept/{deptId}")
	public DepartmentResponse getDepartmentById(@PathVariable Integer deptId);
}
