package com.nau.service;

import com.nau.vo.EmployeeDepartmentResponse;
import com.nau.vo.EmployeeResponse;

public interface EmployeeService {
	
	public EmployeeResponse getEmployeeById(Integer deptId);

	public EmployeeDepartmentResponse getEmpDept(Integer empId);

}
