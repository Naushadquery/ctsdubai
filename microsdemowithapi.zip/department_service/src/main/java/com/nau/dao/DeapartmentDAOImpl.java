package com.nau.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.entity.DepartmentEntity;
import com.nau.repository.DepartmentRepository;


@Repository
public class DeapartmentDAOImpl implements DepartmentDAO {
	
	@Autowired
	private DepartmentRepository departmentRepository;

	@Override
	public Optional<DepartmentEntity>  getDepartmentById(Integer deptId) {
		
		return departmentRepository.findById(deptId);
	}
	
}
