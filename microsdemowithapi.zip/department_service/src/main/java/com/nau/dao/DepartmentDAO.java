package com.nau.dao;

import java.util.Optional;

import com.nau.entity.DepartmentEntity;

public interface DepartmentDAO {
	
	public Optional<DepartmentEntity> getDepartmentById(Integer deptId);

}
