package com.nau.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

public class EmployeeModelTest {

	
	// every method should tested
	// with pass and fail
	
	
	@Test
	@Disabled
	public void equalityTest() {
		Employee e1= new Employee(1,"a");
		e1.setId(1);
		e1.setName("nau");
	
		Employee e3 = new Employee();
		
	}
	
	
	@Test
	public void toStringTest() {
	//	Employee e = new Employee();
	//	e.setId(1);
	//	System.out.println(e);
	//	String res = e.toString();
	//	assertEquals("Employee(id=1, name=null, email=null)", res);//pass
	}
	
	@Test
	public void getIdNotEqualsTest() {
		System.out.println("Test method");
		Employee e = new Employee();
		System.out.println(e);
		e.setId(2);
		String res = e.toString();
		assertNotEquals("Employee(id=0, name=null, email=null)", res); //pass
		
	}
	@Test
	@Disabled
	public void getIdEqualsTest() {
		System.out.println("Test method");
		Employee e = new Employee();
		int res = e.getId();
		assertEquals(0, res);
	}
	
	@Test
	@Disabled
	public void getNameTest() {
		System.out.println("Test method");
		Employee e = new Employee();
		String res = e.getName();
		assertEquals(null, res);
	}
}
