package com.nau.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTimeout;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import com.nau.model.Employee;

class EmployeeServiceTest {

	static EmployeeService employeeService;

	@BeforeAll
	static void beforeAll() {
		employeeService = new EmployeeService();
		System.out.println("before All ");
	}

	@AfterAll
	static void AfterAllTest() {
		employeeService = null;
		System.out.println("After All ");
	}

	@AfterEach
	void AfterEachTest() {
		employeeService = null;
		System.out.println("After Each ");
	}

	@BeforeEach
	void beforeTest() {
		employeeService = new EmployeeService();
		System.out.println("before Each ");
	}

	@Test
	void addEmployeeTest() {
		System.out.println("add test");
		Employee employee = new Employee(1,"naushad");
		String res = employeeService.addEmployee(employee);
		assertEquals("naushad", res);

	}

	@Test // @Test(timeout=1)
	@Timeout(value = 1, unit = TimeUnit.MILLISECONDS)
	void updateEmployeeTest() {
//		System.out.println("update test");
//		Employee employee = new Employee();
//		boolean res = employeeService.updateEmployee(employee);
//		assertEquals(true, res);
//		System.out.println(" Testing Timeout");
//		for(int i =1;i<100000;i++) {
//			System.out.println(i);
//		}
	//	assertTimeout(Duration.ofMillis(100), () -> {
			for (int i = 1; i < 100000; i++) {
				//System.out.println(i);
			}
	//	});
//		assertTimeout(10, () -> {
//			for (int i = 1; i < 100000; i++) {
//				System.out.println(i);
//			}
//		});

	}

}
