package com.nau.logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.*;

public class LoggerDemo {

//	static Logger logger = Logger.getLogger(LoggerDemo.class.getName());
	
	static Logger logger = LoggerFactory.getLogger(LoggerDemo.class);

	public static void main(String[] args) {
		
		
		logger.trace("trace {} and {} ","naushad","Akhtar");
		logger.debug("debug");
		logger.info("info message");
		logger.warn("warn");
		logger.error("error");
			
		
		
//		logger.severe("severe message");
//		logger.warning("warning message");
//		logger.config("config");
//		logger.finest("finest");
//		logger.finer("finer");
//		logger.fine("fine");
		
		
		
	}

}
