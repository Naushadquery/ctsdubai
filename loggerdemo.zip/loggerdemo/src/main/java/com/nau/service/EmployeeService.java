package com.nau.service;



import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.PrintStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.nau.model.Employee;

public class EmployeeService {

	private static Logger logger = LoggerFactory.getLogger("EmployeeService");

	public String addEmployee(Employee employee) {
		employee.tp();
		logger.info("Value of Employee Name : {} " , employee.getName());
		String name = null;
		try {
			int x = employee.getId();
			name = employee.getName();
			name.toUpperCase();
		} catch (Exception e) {
			logger.error(e.getMessage());
			try {
				e.printStackTrace(new PrintStream(new FileOutputStream("error.txt",true)));
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
		}

		return name;
	}

	public boolean updateEmployee(Employee employee) {
		System.out.println(employee);
		int x = employee.getId();

		return true;
	}

	public static void main(String[] args) {

		EmployeeService employeeService = new EmployeeService();
		String s = employeeService.addEmployee(new Employee(1, null));
		System.out.println(s);
	}

}
