 function abc() { // asynchronous
    console.log("acb")
   return Promise.resolve("thank you");
}

async function abc1() { // asynchronous
    console.log("acb1")
   return ("thank you 1");
}

p = abc();
p1= abc1();

p.then((v) => { console.log(v) }, () => { console.log(v) }) // waiting state for abc
p1.then((v) => { console.log(v) }, () => { console.log(v) }) // waiting state for abc1

console.log("end");