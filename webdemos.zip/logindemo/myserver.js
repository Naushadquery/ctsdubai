var express = require('express');
//const  cookieParser  = require('cookie-parser');
const  session  = require('express-session');
const { verify } = require('./loginservice');
var app = express();

//app.use(cookieParser());
app.use(session({ secret: 'nasuhad here' }))

app.get("/", function (req, res) {
    res.sendFile(__dirname + "/login.html");
});

app.get("/login", function (req, res) {

    userid = req.query.userid;
    password = req.query.password;
    console.log(userid + " " + password)

    result = verify(userid, password);
    if (result.result == "1") {

    } else {
        req.session.userid = userid;
        req.session.actualpassword = result.password
    }
    console.log(result);
});

app.listen(80);
console.log('server started');