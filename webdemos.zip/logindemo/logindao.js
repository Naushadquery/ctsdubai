function getUser(userid){


    // db connection

    return {"password":'abcd'};


}

module.exports = {getUser}