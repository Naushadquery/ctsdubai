const { getUser } = require("./logindao");


function verify(userid, password) {
    userinfo = getUser(userid);
   if(userinfo==null){
    return "USer Not Found"
   }else {
    if(password === userinfo.password){
        return {"result":"1"}
    }else{
        return {"result":"2","actualpassword":userinfo.password}
    }
   
   }
}

module.exports = { verify }

