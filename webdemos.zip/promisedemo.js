// setTimeout(function () {
//     funcdemo('akhtar');
// }, 5000);

// funcdemo = function (uname) {
//     console.log("Your name : " + uname);
// }


// prom = new Promise(function (resolve, rejected) {

//     x = 30;

//     if (x == 40) {
//         resolve("x value = " + x);
//     } else
//         rejected("Wrong value");
// });

function dotask(number) {

    pr = new Promise(function (resolve, rejected) {
        if (number == 40) {
            resolve("x value = " + number);
        } else
            rejected("Wrong value " +number);
    });
    return pr;
}

pro = dotask(30)
pro.then(
    (v) => { result(v) },
    (v) => { result(v) }
);

dotask(4).then()


// prom.then(
//     function (resolvedvalue) {
//         result(resolvedvalue)
//     },
//     function (rejectedvalue) {
//         result(rejectedvalue)
//     }
// );

function result(value) {
    console.log(value);
}

console.log("End")