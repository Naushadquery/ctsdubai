var age = 10;

var uname;
age = 1111;
age = 44;
var f = function (x) { console.log("hello" + x); };
var A = /** @class */ (function () {
    function A() {
    }
    return A;
}());
