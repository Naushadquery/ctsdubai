var age = 5;
var uname:string
var count:number  =44;
age = 1111;
age =44;

var f=(x)=>{console.log("hello" + x)};

var ff = function(xx){
    console.log("hello" + xx)
}
function fff(xxx){
    console.log("hello" + xxx)
}

f(4);

var numbers:any;

numbers = "two";
numbers = 2;

class Employee{
    // private name:string;
    // private age:number;
    constructor(private name:string,private age:number){
       this.name = name;
        this.age = age;
    }
}

const employees  = [new Employee("anu",33)];
employees[0] = new Employee("anu",33);

const names:any = ["a","b",0]; // generics
names[0] = 4;
names.push("naushad");
names.push(3);

