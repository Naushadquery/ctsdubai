var x = 10;

x = "naushad";

