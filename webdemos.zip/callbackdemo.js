

function cdemo(x, y, givetotal) {
    z = x + y;
    if (z < 10) {
        setTimeout(()=>{
            return givetotal(z);
        },5000);
    } else {
        setTimeout(()=>{
            return givetotal(0);
        },1000);
    }
}

cdemo(3,4, function (result) {
    console.log(result)
});

console.log("end");