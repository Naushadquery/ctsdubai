function Motasem() {

    return <> 
        <div style={{ color: 'blue' }}>Hello ReactJs - Motasem </div>
        <div>HEllo Motasem { new Date() + ('naushad')}</div>
    </>
}