function Cathy(props) {
    return <div style={{ color: 'red' }}> Hello ReactJs - Cathy , I am doing fine , i am in {props.city} <Motasem/></div> // JSX
}