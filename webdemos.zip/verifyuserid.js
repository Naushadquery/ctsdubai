function verify(){

}

function sendData(){
    
}