package com.nau;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Consumer;

public class SetDemo {

	public static void main(String[] args) {
		
		String s1 = "Aa";
		String s2 = "BB";
		
		//System.out.println(s1.hashCode() + " : " +  s2.hashCode());
		
		EmployeeDTO emp1 = new EmployeeDTO(4, "naushad", "mumbai");
		EmployeeDTO emp2 = new EmployeeDTO(2, "akhtar", "pune");
		EmployeeDTO emp3 = new EmployeeDTO(1, "cathy", "dubai");
		EmployeeDTO emp4 = new EmployeeDTO(0, "jay", "sharjah");
		EmployeeDTO emp5 = new EmployeeDTO(4, "jay", "sharjah");

		List<EmployeeDTO> dtos = new ArrayList<>();
		dtos.add(emp1);
		dtos.add(emp2);
		//displayEmployees(dtos);

		Set<EmployeeDTO> employees = new HashSet<>();
//		System.out.println(employees.add(emp1));
//		System.out.println(employees.add(emp2));
//		System.out.println(employees.add(emp3));
//		System.out.println(employees.add(emp4));
//		System.out.println(employees.add(emp5));
		
		Set<EmployeeDTO> employeest = new HashSet<>();
		System.out.println(employeest.add(emp1));
		System.out.println(employeest.add(emp2));
		System.out.println(employeest.add(emp3));
		System.out.println(employeest.add(emp4));
		System.out.println(employeest.add(emp5));
		sortEmployeeByName(employeest);
//		displayEmployeest(employeest);
		
		
	//	sortEmployees(employees);
		//displayEmployees(employees);
		
		Set<String> names = new HashSet<>();
//		System.out.println(names.add("naushad"));
//		System.out.println(names.add("akhtar"));
//		System.out.println(names.add("akhtar"));
		// displayEmployees(dtos);
	//	displayNames(names);
		
	}

	private static void sortEmployeeByName(Set<EmployeeDTO> employeest) {
		List<EmployeeDTO> elist = new ArrayList<>(employeest);
		Collections.sort(elist);
		
		List<EmployeeDTO> list = new ArrayList<>(employeest);
		list.sort((e1,e2)->e1.getName().compareTo(e2.getName()));
		list.forEach((e)->System.out.println(e));
		
	}
	private static void sortEmployeeById(Set<EmployeeDTO> employeest) {
		List<EmployeeDTO> list = new ArrayList<>(employeest);
		list.sort((e1,e2)->e1.getId() - e2.getId());
		list.forEach((e)->System.out.println(e));
		
	}

	private static void displayEmployeest(Set<EmployeeDTO> employeest) {
		employeest.forEach((e)->System.out.println(e));
		
	}

	private static void sortEmployees(Set<EmployeeDTO> employees) {
		List<EmployeeDTO> list = new ArrayList<>(employees);
		list.sort((e1,e2)->e1.getId() - e2.getId());
		list.forEach((e)->System.out.println(e));
	}

	private static void displayEmployees(Set<EmployeeDTO> employees) {
		employees.forEach((e)->System.out.println(e));
	}

	private static void displayNames(Set<String> names) {
		names.forEach((n) -> System.out.println(n));
	}

	private static void displayEmployees(List<EmployeeDTO> dtos) {
		for (EmployeeDTO emp : dtos) {
			System.out.println(emp);
		}

		Consumer<EmployeeDTO> consumer = new Consumer<EmployeeDTO>() {
			@Override
			public void accept(EmployeeDTO t) {
				System.out.println(t);
			}
		};

		dtos.forEach(consumer);

		dtos.forEach((e) -> System.out.println(e));

	}

}
