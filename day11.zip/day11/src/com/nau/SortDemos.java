package com.nau;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SortDemos {

	public static void main(String[] args) {
		List<String> al = new ArrayList<>(100);
	//	List<String> al = new Vector<>(100,10);  // synchronized
		System.out.println(al.size());
		al.add("rb");
		al.add("z");
		al.add("ra");
		al.add("a");
		al.add("d");
		displaySorted(al);
	}

	private static void displaySorted(List<String> al) {
		Comparator<String> c = new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				int x = o2.compareTo(o1);
				System.out.println(" : " + x);
				return x;
			}
		};
		
		al.sort((s1, s2) -> {
			return s1.compareTo(s2);
		});
		
		al.sort((s1, s2) -> s1.compareTo(s2));
		System.out.println(al);

	}

}
