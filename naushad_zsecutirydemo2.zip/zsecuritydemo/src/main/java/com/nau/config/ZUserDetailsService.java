package com.nau.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.nau.entity.User;
import com.nau.repository.UserRepository;



public class ZUserDetailsService implements UserDetailsService{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		String gotfromuser = username;
		User user= userRepository.getUserByUserName(gotfromuser);
		ZUserDetails userDetails = new ZUserDetails(user);
		return userDetails;
	}

}
