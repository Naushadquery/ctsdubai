package com.nau.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.nau.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer>{
	
	@Query("select u FROM User u WHERE u.username =:username")
	public User getUserByUserName(@Param("username") String username);
	
}

//@Repository
// interface UserRepository1 extends JpaRepository<User, Integer>{
//	
//
//	
//	
//}
