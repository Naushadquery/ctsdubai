package com.nau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.ApplicationContext;

import com.nau.entity.User;
import com.nau.repository.UserRepository;

@SpringBootApplication(exclude = SecurityAutoConfiguration.class)
public class ZsecuritydemoApplication {

	public static void main(String[] args) {
	ApplicationContext ctx=	SpringApplication.run(ZsecuritydemoApplication.class, args);
	UserRepository ur = ctx.getBean(UserRepository.class);
	
	User user =  ur.getUserByUserName("patrick");
	System.out.println(user);
	}

}
