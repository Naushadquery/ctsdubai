package com.nau.view;

import java.util.Scanner;

import com.nau.dto.EmployeeDTO;
import com.nau.service.EmployeeService;
import com.nau.service.EmployeeServiceImpl;

public class EmployeeView {
	
	private  Scanner scanner ;
	{
		scanner = new Scanner(System.in);
	}
	public EmployeeView() {
		displayOptions();
	}
	

	private void displayOptions() {
		System.out.println(" ============  Main Options ==============");
		System.out.println("1. Add Employee");
		System.out.println("2. Delete Employee");
		/////
		System.out.println("Enter Option : ");
		int choice = scanner.nextInt();
		chooseOptions(choice);
	}

	private void chooseOptions(int choice) {
		switch (choice) {
		case 1:
			addEmployee();
			break;

		default:
			break;
		}
	}

	private void addEmployee() {
		System.out.println("Enter ID : ");
		int id = scanner.nextInt();
		System.out.println("Enter Name : ");
		String name = scanner.next();
		EmployeeDTO dto = new EmployeeDTO(id, name);
		EmployeeService service = new EmployeeServiceImpl();
		service.addEmployeeService(dto);
		
	}

}
