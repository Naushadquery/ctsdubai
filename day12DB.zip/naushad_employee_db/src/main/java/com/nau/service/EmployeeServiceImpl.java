package com.nau.service;

import com.nau.dao.EmployeeDAO;
import com.nau.dao.EmployeeDAOImpl;
import com.nau.dto.EmployeeDTO;

public class EmployeeServiceImpl implements EmployeeService {
	
	
	@Override
	public void addEmployeeService(EmployeeDTO dto) {
		dto.setName(dto.getName().toUpperCase());
		
		EmployeeDAO dao = new EmployeeDAOImpl();
		int res = dao.saveEmployee(dto);
		if(res!=0) {
			System.out.println("DATA Saved");
		}else {
			System.out.println("DATA Not Saved");
		}
	}

}
