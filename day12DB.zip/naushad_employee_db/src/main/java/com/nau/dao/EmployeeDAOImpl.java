package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.nau.dto.EmployeeDTO;
import com.nau.util.CTSDBConnection;

public class EmployeeDAOImpl implements EmployeeDAO {

	private Connection con = CTSDBConnection.getConnection();
	
	@Override
	public int saveEmployee(EmployeeDTO dto) {
		String sql = "insert into employee values(?,?)";
		try(PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setInt(1, dto.getId());
			ps.setString(2, dto.getName());
			return ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public EmployeeDTO getEmployee(int id) {
		return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() {
		return null;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO dto) {
		int id = dto.getId();
		
		return null;
	}

	@Override
	public EmployeeDTO deleteEmployee(EmployeeDTO dto) {
		return null;
	}

	@Override
	public List<EmployeeDTO> getEmployeeByCity(String city) {

		return null;
	}


}
