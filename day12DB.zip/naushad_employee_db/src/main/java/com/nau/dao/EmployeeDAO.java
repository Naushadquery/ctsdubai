package com.nau.dao;

import java.util.List;

import com.nau.dto.EmployeeDTO;

public interface EmployeeDAO  {
	
	
	public int saveEmployee(EmployeeDTO dtos);// return total employees added
	public EmployeeDTO getEmployee(int id);
	public List<EmployeeDTO> getAllEmployee();
	public EmployeeDTO updateEmployee(EmployeeDTO dto);
	public EmployeeDTO deleteEmployee(EmployeeDTO dto);
	public List<EmployeeDTO> getEmployeeByCity(String city);
 
}
