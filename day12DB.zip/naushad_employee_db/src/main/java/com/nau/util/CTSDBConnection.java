package com.nau.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CTSDBConnection {
	
	private static Connection connection;
	
	static {
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ctsdubai","hr","hr");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		return connection;
	}
	
	
}
