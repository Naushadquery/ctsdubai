
package com.nau;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.cts.service.CalculatorService;

public class CalculatorClient {
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {

		Registry rr = LocateRegistry.getRegistry("192.168.29.51",2222);
		
		Remote remote=  rr.lookup("naucalc");
		//  proxy object dowloaded
		CalculatorService calculatorService = 
				(CalculatorService)remote;
		int s = calculatorService.add(233, 44);
		System.out.println(s);
	}
}
