package com.cts.service;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface CalculatorService extends Remote {

	public int add(int i, int j) throws RemoteException;

}
