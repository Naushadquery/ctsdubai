package com.cts.service;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class DeployCalculator {
	
	public static void main(String[] args) {
		
		
		
		try {
			CalculatorService caluclatorService = new CalculatorServiceImpl();
			Registry registry = LocateRegistry.createRegistry(2222);
			registry.rebind("naucalc", caluclatorService);
			System.out.println("Object Binded .. Calcuator Ready for Use");
			
		} catch (RemoteException e) {
		
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
