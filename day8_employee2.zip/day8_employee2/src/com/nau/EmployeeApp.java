package com.nau;

import com.nau.view.EmployeeView;

public class EmployeeApp {
	
	public static void main(String[] args) {
		
		new EmployeeView();
		
	}

}
