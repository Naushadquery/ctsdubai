package com.nau.service;

import com.nau.dto.EmployeeDTO;

public interface EmployeeService {
	
	
	public String addEmployee(EmployeeDTO employeeDTO);
	public EmployeeDTO[] getEmployees();
	public void persist();

}
