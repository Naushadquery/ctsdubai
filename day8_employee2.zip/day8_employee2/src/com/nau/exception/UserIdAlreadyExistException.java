package com.nau.exception;

public class UserIdAlreadyExistException extends Exception{
	
	public UserIdAlreadyExistException() {
	
	}
	public UserIdAlreadyExistException(String msg) {
		super(msg);
	}
}
