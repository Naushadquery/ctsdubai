package com.nau.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.nau.dto.EmployeeDTO;

public class EmployeeDAOImpl implements EmployeeDAO {

	private static EmployeeDTO employeeDTO[];
	static int empcount;
	static {
		File file = new File("employees.ser");
		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file); ObjectInputStream ois = new ObjectInputStream(fis)) {
				Object obj = ois.readObject();
				employeeDTO = (EmployeeDTO[]) obj;
				for (EmployeeDTO emp : employeeDTO) {
					if (emp != null) {
						empcount++;
					}
				}
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}
		} else {
			employeeDTO = new EmployeeDTO[100];
		}

//	// employeeDTO[0] = new EmployeeDTO(1, "naushad", "akhtar", "mumbai");
////		employeeDTO[1] = new EmployeeDTO(2, "Rahel", "ahmed", "dubai");
//	for(
//	EmployeeDTO emp:employeeDTO)
//	{
//		if (emp != null) {
//			empcount++;
//		}
//	}
//	}
	}

	@Override
	public boolean saveEmployee(EmployeeDTO dto) {

		System.out.println(employeeDTO.length);
		employeeDTO[empcount++] = dto;
		System.out.println(empcount);

		return true;
	}

	@Override
	public void persist() {

		try (FileOutputStream fos = new FileOutputStream("employees.ser");
				ObjectOutputStream oos = new ObjectOutputStream(fos)) {
			oos.writeObject(employeeDTO);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public EmployeeDTO[] getAllEmployees() {

		System.out.println("in dao");

		return employeeDTO;
	}
}
