package com.nau.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.nau.dto.EmployeeDTO;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	private static Set<EmployeeDTO>  employeeDTOs;
	
	static {
		employeeDTOs = new HashSet<>();
		employeeDTOs.add(new EmployeeDTO(1, "NAUSHAD", "Mumbai"));
		employeeDTOs.add(new EmployeeDTO(2, "AKTHAR", "Goa"));
		employeeDTOs.add(new EmployeeDTO(3, "JAY", "Dubai"));
		employeeDTOs.add(new EmployeeDTO(4, "AMIT", "Dubai"));
	}

	@Override
	public int addEmployee(List<EmployeeDTO> dtos) {
		return 0;
	}

	@Override
	public EmployeeDTO getEmployee(int id) {
		return null;
	}

	@Override
	public List<EmployeeDTO> getAllEmployee() {
		return null;
	}

	@Override
	public EmployeeDTO updateEmployee(EmployeeDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDTO deleteEmployee(EmployeeDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public List<EmployeeDTO> getEmployeeByCity(String city) {
		
		return null;
	}
	
	

}
