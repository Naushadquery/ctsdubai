package com.nau;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;

import com.nau.exception.IntegerValueNotInRangeException;

public class Calculator {
	
	public int doAddition(int i, int j)throws IntegerValueNotInRangeException {
		if(i<100) {
			throw new IntegerValueNotInRangeException("Value " + i + " is less than 100, try again");
		}
		
		try {
			FileReader fileReader = new FileReader("Asdf");
			try {
				ServerSocket serverSocket= new ServerSocket();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return i+j;
	}

}
