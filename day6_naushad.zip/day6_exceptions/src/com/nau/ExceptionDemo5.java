package com.nau;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ExceptionDemo5 {
	public static void main(String[] args) {

		System.out.println("start");
		FileInputStream fileInputStream = null;
		;
		try {
			fileInputStream = new FileInputStream("abc.txt");
			System.out.println(fileInputStream);
			fileInputStream.read();

		} catch (FileNotFoundException e) {
			System.out.println("File does not exist currently, visit tomorrow");
			// e.printStackTrace();
		} catch (IOException e) {
			System.out.println("No Read Persmission");
			e.printStackTrace();
		} finally {
			System.out.println("finally");
			if(fileInputStream!=null) {
				try {
					System.out.println("before close f");
					fileInputStream.close();
					System.out.println("after close f");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("End");
	}
}
