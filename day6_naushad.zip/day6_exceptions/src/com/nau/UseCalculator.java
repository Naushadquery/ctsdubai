package com.nau;

import com.nau.exception.IntegerValueNotInRangeException;

public class UseCalculator {
	public static void main(String[] args) {

		Calculator calculator = new Calculator();
		int res;
		try {
			res = calculator.doAddition(14, 12);
			System.out.println(res);
		} catch (IntegerValueNotInRangeException e) {
			System.out.println(e.getMessage());
		}
	}
}
