package com.nau;

public class Motasem {

	public String bringMarker(String color) throws Exception {
		return shannonGetMarker(color);
	}
	private String shannonGetMarker(String color) throws Exception {
		return aakil(color);
	}

	private String aakil(String color) throws Exception {
		return hania(color);
	}

	private String hania(String color) throws Exception {
			String s= "";
			s= shop(color);
			return s;
	}

	private String shop(String color) throws Exception {
		String col = "red";
		if (color.equals(col)) {
			return color + " marker ";
		} else {
			throw new Exception(color + " marker not available");
		}
		
	}
}
