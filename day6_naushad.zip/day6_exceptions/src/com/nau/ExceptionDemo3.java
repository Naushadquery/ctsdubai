package com.nau;

public class ExceptionDemo3 {
	public static void main(String[] args) {

		System.out.println("Start");

		try {
			// code
			String b = args[0];
			int a = Integer.parseInt(b);
			int x = 60000 / a;
			System.out.println(x);
			int y = 33 / 0;
		} catch (ArrayIndexOutOfBoundsException | NumberFormatException e ) {
			String s = e.getMessage();
			//System.out.println(s);
			//System.out.println(e.toString());
			System.out.println(e.initCause(e));
			System.out.println("Array Length not ok");
		} catch (ArithmeticException e) {
			System.out.println("Demnominator reached to 0");
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("End");
	}
}
