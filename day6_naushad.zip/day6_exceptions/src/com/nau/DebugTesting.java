package com.nau;

public class DebugTesting {
	
	int a = 50;
	
	public static void main(String[] args) {
		
		DebugTesting d =	new DebugTesting();
		System.out.println(d.a);
		int x = 10;
		System.out.println("start");
		
		tp();
		
		System.out.println("end");
		
	}

	private static void tp() {
		int x = 5;
		int y =666;
		boolean g = true;
		System.out.println("end of tp");
		
	}

}
