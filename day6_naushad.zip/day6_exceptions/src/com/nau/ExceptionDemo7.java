package com.nau;

public class ExceptionDemo7 {
	public static void main(String[] args) throws InterruptedException {

		System.out.println("start");
		
		Motasem motasem = new Motasem();
		try {
			System.out.println("Fetching blue");
			String marker = motasem.bringMarker("blue");
			System.out.println(marker);
		} catch (Exception e) {
			String marker;
			e.printStackTrace();
			try {
				marker = motasem.bringMarker("green");
				System.out.println(marker);
			} catch (Exception e1) {
				try {
					marker = motasem.bringMarker("red");
					System.out.println(marker);
				} catch (Exception e2) {
					e2.printStackTrace();
				}
				System.out.println(e1.getMessage());
			}
		}
			
		
		System.out.println("End");
	}
}
