package com.nau;

import java.io.FileInputStream;

public class ExceptionDemo {
	public static void main(String[] args) {
		
		System.out.println("Start");
		
		// Runtime // shuould never caught // handle programatically
		if(args.length==0) {
			System.out.println("Please enter value from command line");
		}else {
			String s = args[0]; 
			System.out.println(s);
		}
		
	//	Thread.sleep(5000); // Compile Time
	//	new FileInputStream("abcc.txt");
		
		System.out.println("End");
	}
}
