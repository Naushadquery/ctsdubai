package com.nau;

public class ExceptionDemo4 {
	public static void main(String[] args) {

		try {
			System.out.println("car engine started ");
			int x = 5 /0;
			System.out.println("car reached destination");
		} catch (Exception e) {
			System.out.println("flat tyre");
			System.out.println("Replace Tyre");
 		} finally {
			System.out.println("car engine stopped");
			System.out.println("finally");
		}
		System.out.println("End");
	}
}
