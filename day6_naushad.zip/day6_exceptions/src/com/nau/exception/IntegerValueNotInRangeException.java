package com.nau.exception;

public class IntegerValueNotInRangeException extends Exception {
	public IntegerValueNotInRangeException(String message) {
		super(message);
	}
}
