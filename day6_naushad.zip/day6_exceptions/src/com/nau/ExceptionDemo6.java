package com.nau;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

class MyConnection implements Closeable {

	@Override
	public void close() throws IOException {
		System.out.println("closing Connection");
	}
}

public class ExceptionDemo6 {
	public static void main(String[] args) {

		System.out.println("start");
		try (MyConnection connection = new MyConnection(); 
				FileInputStream fis = new FileInputStream("asdf")) {
			System.out.println("All Done");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		System.out.println("End");
	}
}
