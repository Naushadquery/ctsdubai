package com.nau;

public class ExceptionDemo2 {
	public static void main(String[] args) {
		// try, catch, finally, throw, throws.
		System.out.println("Start");
		tp(null);
		System.out.println("End");
	}

	public static void tp(String name) {
		//int x  =1/0;
		tp1(name);
	}
	public static void tp1(String name) {
		System.out.println("in tp1");
	//	try {
			String s = name;
			System.out.println("S : " + s.toLowerCase());
//		} catch (Exception e) {
//			System.out.println("errrr1");
//			e.printStackTrace();
//			System.out.println("errrr2");
//			// System.out.println("Error occured");
//		}
		System.out.println("out tp1");
	}
}
