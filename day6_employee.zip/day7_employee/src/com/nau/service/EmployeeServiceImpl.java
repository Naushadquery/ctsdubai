package com.nau.service;

import com.nau.dao.EmployeeDAO;
import com.nau.dao.EmployeeDAOImpl;
import com.nau.dto.EmployeeDTO;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDAO dao = new EmployeeDAOImpl();
	@Override
	public String addEmployee(EmployeeDTO employeeDTO) {
		// System.out.println("Saved + " + employeeDTO);
		employeeDTO.setFirstName(employeeDTO.getFirstName().toUpperCase());
		employeeDTO.setLastName(employeeDTO.getLastName().toUpperCase());

		
		if (dao.saveEmployee(employeeDTO)) {
			return "Data Save Successfully";
		} else {
			return "Data Insertion Failed";
		}
	}
	
	@Override
	public EmployeeDTO[] getEmployees() {
		EmployeeDTO[] employees = dao.getAllEmployees();
		return employees;
	}
}
