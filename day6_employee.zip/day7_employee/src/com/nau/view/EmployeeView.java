package com.nau.view;

import java.util.Scanner;

import com.nau.dto.EmployeeDTO;
import com.nau.service.EmployeeService;
import com.nau.service.EmployeeServiceImpl;

public class EmployeeView {
	private EmployeeService employeeService = new EmployeeServiceImpl();

	private static Scanner scanner;
	static {
		scanner = new Scanner(System.in);
	}
	
	public EmployeeView() {
		mainOptions();
	}

	private void mainOptions() {
		
		System.out.println("===== Main =====");
		System.out.println("1. Add Employee");
		System.out.println("2. Display Employee");
		System.out.println("3. Exit");
		
		System.out.println("Enter Option : ");
		int option = scanner.nextInt();
		doOptions(option);
	}

	private void doOptions(int option) {
		switch (option) {
		case 1: {
			addEmployeeView();
			mainOptions();
		}case 2 :{
			displayEmployee();
			mainOptions();
		}
		case 3 : {
			System.exit(0);
			//break;
		}
		
		default:
			throw new IllegalArgumentException("Unexpected value: " + option);
		}
	}

	private void displayEmployee() {
		
		EmployeeDTO[]  employees =  employeeService.getEmployees();
		
		
	}

	private void addEmployeeView() {
		System.out.println("Enter ID : ");
		int id = scanner.nextInt();
		System.out.println("Enter First Name");
		String firstName = scanner.next();
		System.out.println("Enter Last Name");
		String lastName = scanner.next();
		System.out.println("Enter City");
		String city = scanner.next();
		EmployeeDTO dto = new EmployeeDTO(id, lastName, firstName, city);
		String result = employeeService.addEmployee(dto);
		System.out.println(result);
	}
}
