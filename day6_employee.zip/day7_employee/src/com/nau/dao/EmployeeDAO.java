package com.nau.dao;

import com.nau.dto.EmployeeDTO;

public interface EmployeeDAO {
	
	public boolean saveEmployee(EmployeeDTO dto);
	public EmployeeDTO[] getAllEmployees();

}
