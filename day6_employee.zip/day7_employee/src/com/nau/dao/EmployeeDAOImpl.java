package com.nau.dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import com.nau.dto.EmployeeDTO;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	private static File file;
	private static FileWriter fileWriter;
	static {
		file = new File("employees.csv");
		try {
			fileWriter = new  FileWriter(file,true);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean saveEmployee(EmployeeDTO dto) {
		boolean result = false;
		int id = dto.getId();
		String lastName = dto.getLastName();
		String firstName = dto.getFirstName();
		String city = dto.getCity();
		try {
			fileWriter.write(id+" "+lastName+" "+firstName+" "+city+"\n" );
			fileWriter.flush();
			System.out.println("saved : " + dto);
			result = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public EmployeeDTO[] getAllEmployees() {
		
		return null;
	}
}
