package com.nau.main;

public class MainApp {
	
	public static void main(String[] args) {
		
		new JDBCDemo();
		
	}

}
