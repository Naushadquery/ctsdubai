package com.nau.main;

public class UserIdNotFoundException extends Exception{
	
	public UserIdNotFoundException(String message) {
		super(message);
	}
}
