package com.nau.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

class A {
	private static A a;

	static {
		a = new A();
	}

	A() {
		System.out.println("A object created");
	}
}

public class JDBCDemo {

	private Scanner scanner = new Scanner(System.in);
	static String url;
	static Connection con;
	static {
		url = "jdbc:mysql://localhost:3306/ctsdubai";
		try {
			DriverManager.getConnection(url, "hr", "hr");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public JDBCDemo() {
		// addEmployee();
		try {
			getEmployee();
		} catch (UserIdNotFoundException e) {
			System.out.println(e.getMessage());
			try {
				getEmployee();
			} catch (UserIdNotFoundException e1) {
				e1.printStackTrace();
			}
		}
		// getEmployees();
	}

	private void getEmployee() throws UserIdNotFoundException {
		System.out.println("Enter ID : ");
		int id = scanner.nextInt();
		String sql = "select * from employee where id = ?"; // DQL
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				int rid = rs.getInt(1);
				String rname = rs.getString(2);
				System.out.println(rid + " : " + rname);
			} else {
				throw new UserIdNotFoundException("No Records Found for id " + id + " please try again");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	private void getEmployees() {
		String sql = "select id,name from employee"; // DQL
	//	String url = "jdbc:mysql://localhost:3306/ctsdubai";
		try {
		//	Connection con = DriverManager.getConnection(url, "hr", "hr");
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				int rid = rs.getInt("id");
				String rname = rs.getString("name");
				System.out.println(rid + " : " + rname);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	private void addEmployee() {
		System.out.println("Enter ID : ");
		int id = scanner.nextInt();
		System.out.println("Enter Name : ");
		String name = scanner.next();
		EmployeeDTO dto = new EmployeeDTO(id, name);
		serviceData(dto);

	}

	private void serviceData(EmployeeDTO dto) {
		dto.setName(dto.getName().toUpperCase());
		saveInDatabase(dto);
	}

	private void saveInDatabase(EmployeeDTO dto) {
		try {
			// java.sql.Driver driver = new com.mysql.cj.jdbc.Driver() ;
			// DriverManager.registerDriver(new Driver());
			// Class.forName("com.mysql.cj.jdbc.Driver");

			int id = dto.getId();
			String name = dto.getName();

			String sql = "insert into employee values(?,?)";
			// con.createStatement();
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, name);

			int res = ps.executeUpdate(); // DML
			System.out.println(res);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
