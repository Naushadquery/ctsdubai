package com.nau.loginservice.dto;

import lombok.Data;

@Data
public class ValidateResponse {
	
	private String message;
	private String fullName;
	
}
