package com.nau.loginservice.dto;

import lombok.Data;

@Data
public class ValidateRequest {
	
	
	private Integer userid;
	private String password;

}
