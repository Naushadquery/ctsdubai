package com.nau.loginservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nau.loginservice.entity.LoginUserDetails;

public interface LoginUserDetailsRepository extends JpaRepository<LoginUserDetails, Integer>{

}
