package com.nau.loginservice.entity;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "loginuser")
public class LoginUser { // login_user
	
	@Id
	@Column(name = "loginid" ,length = 6)
	private Integer loginId;
	
	@Column(name="password" , length = 10)
	private String password;

	@Column(name="status" )
	private boolean status = true;
	
	@Column(name="creationtime" )
	private Date creationTime = new Date() ;
	 
	@Column(name="isnew")
	private boolean isNew = true; 
		
}
