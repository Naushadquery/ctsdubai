package com.nau.loginservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.nau.loginservice.dao.LoginUserDAOImpl;

@SpringBootApplication
public class LoginServiceApplication {

	public static void main(String[] args) {
	ApplicationContext ctx =   SpringApplication.run(LoginServiceApplication.class, args);
	LoginUserDAOImpl dao =ctx.getBean(LoginUserDAOImpl.class);
	
	
	
	
//	LoginUser loginUser = new LoginUser();
//	loginUser.setLoginId(127);
//	loginUser.setPassword("abc");
//	//loginUser.setStatus(true);
//	//loginUser.setNew(false);
//	//loginUser.setCreationTime(new Date(new java.util.Date().getTime()));
//	dao.addLoginUser(loginUser);

		
	}

}
 