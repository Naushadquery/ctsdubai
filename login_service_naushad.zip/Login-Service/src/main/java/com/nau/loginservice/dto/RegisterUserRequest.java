package com.nau.loginservice.dto;

public class RegisterUserRequest {

}
