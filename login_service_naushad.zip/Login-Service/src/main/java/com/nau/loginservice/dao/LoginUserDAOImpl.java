package com.nau.loginservice.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.loginservice.entity.LoginUserDetails;
import com.nau.loginservice.repository.LoginUserDetailsRepository;
import com.nau.loginservice.repository.LoginUserRepository;

@Repository
public class LoginUserDAOImpl {
	
	@Autowired
	private LoginUserRepository loginUserRepository;
	
	@Autowired
	private LoginUserDetailsRepository loginUserDetailsRepository;
	
	public void addLoginUser(LoginUserDetails loginUserDetails) {
		loginUserDetailsRepository.save(loginUserDetails);
	}
	

}
