package com.nau.loginservice.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.nau.loginservice.dto.RegisterUserRepsonse;
import com.nau.loginservice.dto.RegisterUserRequest;
import com.nau.loginservice.dto.ValidateRequest;
import com.nau.loginservice.dto.ValidateResponse;




@RestController
@RequestMapping("login")
public class LoginController {
	
	
//	@PostMapping(path = "verify" , produces = {MediaType.APPLICATION_JSON_VALUE})
	@RequestMapping(path = {"verify","validate"} , method = {RequestMethod.POST})
	//public String validate(Integer userid, String password) {
	public ValidateResponse validate(@RequestBody ValidateRequest request) {
		System.out.println(request);
		
		// apply logic for validation
		ValidateResponse vr = new ValidateResponse();
		vr.setMessage("Welcome Boss , " + request.getUserid());;
		return vr;
	}
	
	
	@RequestMapping(path = {"add","register"} , method = {RequestMethod.POST})
	public RegisterUserRepsonse registerUser(@RequestBody RegisterUserRequest request) {
		System.out.println(request);
		
		// apply logic for validation
		RegisterUserRepsonse rur = new RegisterUserRepsonse(); // come from service
		
		RegisterUserRepsonse rr = null;//  service.registerNewUser(request)
		rur.setMessage("Add Successfully , " );;
		return rur;
	}

	
}
