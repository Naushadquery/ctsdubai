package com.nau.loginservice.dto;

import lombok.Data;

@Data
public class RegisterUserRepsonse {
	private String message;
}
