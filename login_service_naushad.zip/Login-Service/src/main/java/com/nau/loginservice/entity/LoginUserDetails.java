package com.nau.loginservice.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import lombok.Data;


@Data
@Entity
@Table(name = "loginuserdetails")
public class LoginUserDetails {

	@Id
	@PrimaryKeyJoinColumn()
	@Column(name="loginid")
	private Integer loginId;
	
	@Column(name = "lastname")
	private String lastName;
	
	@Column(name = "firstname")
	private String firstName;
	@Column(name = "email", unique = true)
	private String email;
	  
	@OneToOne(fetch = FetchType.EAGER , cascade = CascadeType.ALL)
	private LoginUser loginUser;
	
}
