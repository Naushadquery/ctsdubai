package com.nau.service;

import com.nau.dao.EmployeeDAO;
import com.nau.dao.EmployeeDAOImpl;
import com.nau.dto.EmployeeDTO;

public class EmployeeServiceImpl implements EmployeeService {
	private EmployeeDAO dao = new EmployeeDAOImpl();
	@Override
	public String addEmployee(EmployeeDTO employeeDTO) {
		// System.out.println("Saved + " + employeeDTO);
		employeeDTO.setFirstName(employeeDTO.getFirstName().toUpperCase());
		employeeDTO.setLastName(employeeDTO.getLastName().toUpperCase());

		EmployeeDTO employees[] = getEmployees();
		for(EmployeeDTO emp : employees) {
			if(emp.getId()==employeeDTO.getId()) {
				return "Employee with " + employeeDTO.getId() + " already exist";
			}
		}
		
		if (dao.saveEmployee(employeeDTO)) {
			return "Data Save Successfully";
		} else {
			return "Data Insertion Failed";
		}
	}
	 
	@Override
	public EmployeeDTO[] getEmployees() {
		System.out.println("get employees in service");
		EmployeeDTO[] employees = dao.getAllEmployees();
		return employees;
	}
}
