package com.nau.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.stream.Stream;

import com.nau.dto.EmployeeDTO;

public class EmployeeDAOImpl implements EmployeeDAO {
	
	private static File file;
	private static FileWriter fileWriter;
	static {
		file = new File("employees.csv");
		try {
			fileWriter = new  FileWriter(file,true);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean saveEmployee(EmployeeDTO dto) {
		
		boolean result = false;
		int id = dto.getId();
		String lastName = dto.getLastName();
		String firstName = dto.getFirstName();
		String city = dto.getCity();
		try {
			fileWriter.write(id+" "+lastName+" "+firstName+" "+city+"\n" );
			fileWriter.flush();
			System.out.println("saved : " + dto);
			result = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	@Override
	public EmployeeDTO[] getAllEmployees() {
		System.out.println("in dao");
		Scanner scanner=null;
		int totalRecords=0;
		try {
			scanner = new Scanner(file);
			Stream<String> st= Files.lines(Paths.get(""+file)) ;
			totalRecords = (int)st.count();
		} catch (IOException e) {
			e.printStackTrace();
		}
//		int rowCount=0;
//		while(scanner.hasNextLine()) {
//			rowCount++;
//			scanner.nextLine();
//			
//		}
		EmployeeDTO employees[] = new EmployeeDTO[totalRecords]; 
		
		for (int i = 0; i < employees.length; i++) {
			String employee = scanner.nextLine();
			
			//EmployeeDTO employeeDTO = employees[i];
			
		}
		
		
		
		return employees;
	}
}
