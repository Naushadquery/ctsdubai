package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.nau.service.VerifyUser;

@RequestMapping("login")
@Controller
public class LoginController {
	
	
	@Autowired
	private VerifyUser verifyUser;
	
	@GetMapping
	@RequestMapping("loginpage")
	public String loginPage() {
		
		return "login";
	}
	
	
	@PostMapping
	@RequestMapping("verifylogin")
	public String verifyUser(@JsonFormat LoginRequest loginRequest, Model model) {
		System.out.println(loginRequest);
		String message = verifyUser.verifyUser(loginRequest);
		switch (message) {
		case "1": {
			model.addAttribute("message",loginRequest.getUserId());
			return "welcome";
			
		}
		case "2": {
			model.addAttribute("message","Sorry, Invalid password");
			return "forward:loginpage";
		}
		case "3": {
			model.addAttribute("message","Sorry, User Id");
			return "forward:loginpage";
		}
		case "4": {
			return "something wrong on server";
		}
		default:
			throw new IllegalArgumentException("Unexpected value: " + message);
		}
	}

}
