package com.nau.dto;

import lombok.Data;

@Data
public class LoginResp {
	private String  message;

}
