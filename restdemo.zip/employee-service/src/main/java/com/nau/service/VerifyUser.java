package com.nau.service;

import com.nau.controller.LoginRequest;

public interface VerifyUser {
	
	public String verifyUser(LoginRequest loginRequest);

}
