package com.nau.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nau.controller.LoginRequest;
import com.nau.dto.LoginResp;

@Service
public class VerifyUserImpl implements VerifyUser {

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public String verifyUser(LoginRequest loginRequest) {

		String endpointurl = "http://localhost:8080/googlelogin/verify";
		ResponseEntity<LoginResp> rs = restTemplate.postForEntity(endpointurl, loginRequest, LoginResp.class);
		LoginResp rsp = rs.getBody();
		String message = rsp.getMessage();

		return message;

	}

}
