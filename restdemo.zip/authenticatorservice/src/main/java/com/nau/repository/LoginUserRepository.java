package com.nau.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nau.entity.LoginUser;

public interface LoginUserRepository extends  JpaRepository<LoginUser, Integer>{

}
