package com.nau.dao;

import java.util.Optional;

import com.nau.entity.LoginUser;

public interface LoginDAO {
	
	public Optional<LoginUser> getLoginUser(Integer id);

}
