package com.nau.dao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nau.entity.LoginUser;
import com.nau.repository.LoginUserRepository;


@Repository
public class LoginDAOImpl implements LoginDAO{
	
	@Autowired
	private LoginUserRepository loginUserRepository;

	@Override
	public Optional<LoginUser> getLoginUser(Integer id) {
		
		Optional<LoginUser> optional = loginUserRepository.findById(id);
		
		return optional;
	}

}
