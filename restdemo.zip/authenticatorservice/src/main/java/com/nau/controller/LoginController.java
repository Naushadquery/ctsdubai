package com.nau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.dto.LoginRequest;
import com.nau.dto.LoginResponse;
import com.nau.service.LoginService;


// contact for FY Eng : maths // address 


@RestController
@RequestMapping("googlelogin") // http://www.googleauth/login/verify {userid,password}
public class LoginController {
	
	@Autowired
	private LoginService loginService;

	@PostMapping(produces = { MediaType.APPLICATION_JSON_VALUE }, consumes = { MediaType.APPLICATION_JSON_VALUE })
	@RequestMapping("verify")
	public LoginResponse verify(@RequestBody  LoginRequest loginRequest) {
		System.out.println(loginRequest);
		
		//

		return loginService.verify(loginRequest);
	}

}
