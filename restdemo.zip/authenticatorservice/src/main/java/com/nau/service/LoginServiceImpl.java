package com.nau.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nau.dao.LoginDAO;
import com.nau.dto.LoginRequest;
import com.nau.dto.LoginResponse;
import com.nau.entity.LoginUser;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO loginDAO;

	@Override
	public LoginResponse verify(LoginRequest loginRequest) {
		String message = null;
		//String errMessage = null;
		// go to database and verify user
		try {

			Optional<LoginUser> optional = loginDAO.getLoginUser(loginRequest.getUserId());
			if (optional.isPresent()) {
				LoginUser loginUser = optional.get();
				if (loginUser.getPassword().equals(loginRequest.getPassword())) {
					message = "1";
				} else {
					message = "2";
				}
			} else {
				message = "3";
			}
		} catch (Exception e) {
			message = "4";
		}
	//	LoginResponse loginResponse = LoginResponse.builder().message(message).errMessage(errMessage).build();
		LoginResponse loginResponse = new LoginResponse();
		loginResponse.setMessage(message);
		return loginResponse;
	}
}
