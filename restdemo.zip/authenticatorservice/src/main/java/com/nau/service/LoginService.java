package com.nau.service;

import com.nau.dto.LoginRequest;
import com.nau.dto.LoginResponse;

public interface LoginService {
	
	public LoginResponse verify(LoginRequest loginRequest);

}
